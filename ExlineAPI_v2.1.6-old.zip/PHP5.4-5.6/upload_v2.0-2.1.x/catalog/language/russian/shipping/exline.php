<?php
// Text
$_['text_title']       = 'Доставка Exline';
$_['text_description'] = 'Доставка Exline';

// Error
$_['error_destination_city']   = '<span style="color: red;">Уточните "Город"</span>';